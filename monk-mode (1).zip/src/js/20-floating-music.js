/* ===== v8: floating music icon — always on top, live centre animation, hide + Ctrl+M ===== */
const MF={raf:0,last:0,f:new Uint8Array(64),td:new Uint8Array(128),PS:{}};
const mzNodes=()=>['mzf','mzp','mzg'].map(i=>document.getElementById(i)).filter(Boolean);
function mzHome(){mzNodes().forEach(n=>{if(n.parentNode!==document.body)document.body.appendChild(n)})}
function mzfVis(){const f=$('#mzf');if(f)f.classList.toggle('hid',!!(MZ.hide||MZ.h2))}
{$('#mzf').innerHTML='<s class="mzhalo"></s><s class="mzdash"></s><i><canvas id="mzfc"></canvas><b>♪</b></i>';
 const g=$('#mzg');if(g){g.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h11M3 12h11M3 18h6"/><path d="M21 4v12"/><circle cx="18" cy="16" r="3"/></svg>';g.removeAttribute('title')}}
/* keep the icon visible while a file / PDF is in browser fullscreen */
document.addEventListener('fullscreenchange',()=>{const fe=document.fullscreenElement;if(!fe||fe.id==='mzs'||fe===document.documentElement||fe===document.body)return mzHome();mzNodes().forEach(n=>fe.appendChild(n))});
{const _f=fvClose;fvClose=function(){mzHome();_f()};ACT.fvX=()=>fvClose()}
/* live centre animation inside the round icon */
function mzfLoop(ts){const f=$('#mzf');if(!f){MF.raf=0;return}
 const pl=!AU.paused&&!!AU.src&&MZ.an,cn=MZ.cen||'vinyl',cv=!!pl&&cn!=='vinyl'&&cn!=='off'&&!MZ.st&&!f.classList.contains('hid');
 f.classList.toggle('cv',cv);if(!pl){MF.raf=0;return}
 MF.raf=requestAnimationFrame(mzfLoop);if(!cv||document.hidden||ts-MF.last<33)return;MF.last=ts;
 const c=$('#mzfc'),s=c.clientWidth||54,d=Math.min(devicePixelRatio||1,2),z=Math.round(s*d);if(c.width!==z){c.width=c.height=z;MF.PS={}}
 const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);x.globalCompositeOperation='source-over';x.clearRect(0,0,s,s);x.lineCap='round';
 try{MZ.an.getByteFrequencyData(MF.f);MZ.an.getByteTimeDomainData(MF.td);let bs=0;for(let i=0;i<6;i++)bs+=MF.f[i];const[A,B]=cols();MC[cn](x,s,s,MF.f,bs/1530,performance.now()/1000,A,B,s/2,s/2,s*.24,MF.td)}catch(e){}
 x.globalCompositeOperation='source-over'}
const mzfGo=()=>{if(!MF.raf)MF.raf=requestAnimationFrame(mzfLoop)};
['play','pause','loadedmetadata'].forEach(v=>AU.addEventListener(v,mzfGo));mzfGo();
/* hide / show (session only — comes back on every fresh load) */
{const _p=mzPanel;mzPanel=function(){return _p().replace('data-act="mzSec">Open Music section ↗</button>','data-act="mzSec">Open Music section ↗</button><button class="btn g s" style="margin-top:8px;width:100%" data-act="mzHid2">🙈 Hide icon · Ctrl+M to bring back</button>')}}
const mzfToggle=()=>{if(MZ.hide||MZ.h2){MZ.h2=false;if(MZ.hide){MZ.hide=false;mz2()}$('#mzp').classList.remove('open');mzfVis();mzfGo();toast('Music icon is back','ok')}else{MZ.h2=true;$('#mzp').classList.remove('open');mzfVis();toast('Music icon hidden — press Ctrl+M to show it')}};
ACT.mzHid2=mzfToggle;
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey&&(e.key==='m'||e.key==='M')){e.preventDefault();mzfToggle()}});
mzfVis();

