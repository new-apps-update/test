/* ===== Extra quest picker · Bio blocks · readable book covers ===== */
(()=>{const st=document.createElement('style');st.textContent=`
.bkc{aspect-ratio:auto;min-height:210px;padding:18px 12px 14px 24px;background:linear-gradient(155deg,color-mix(in srgb,var(--c) 72%,#000),color-mix(in srgb,var(--c) 40%,#000));box-shadow:0 12px 24px rgba(0,0,0,.42),inset 0 0 0 1px rgba(255,255,255,.18)}
.bkc::before{background:linear-gradient(90deg,rgba(0,0,0,.55),rgba(0,0,0,.15) 65%,rgba(255,255,255,.18))}
.bkf{border:1.5px solid rgba(255,255,255,.38);inset:9px 9px 9px 20px}
.bkc .bki{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;font-size:1.7rem;margin-top:4px;background:rgba(255,255,255,.2);box-shadow:inset 0 0 0 1px rgba(255,255,255,.4);filter:none}
.bkc .bkt{width:100%;background:#fbf6e9;color:#1b1b22;font-size:1rem;font-weight:800;line-height:1.4;text-shadow:none;overflow-wrap:anywhere;padding:9px 8px;border-radius:6px;box-shadow:0 3px 8px rgba(0,0,0,.35),inset 0 0 0 1px rgba(0,0,0,.08)}
.bkc .bkm{color:#fff;font-size:.74rem;font-weight:700;text-shadow:0 1px 2px rgba(0,0,0,.7)}
.bkc .bkm i{background:rgba(0,0,0,.4)}
.bkc .bkm i b{background:#fff}
.bko-book{background:var(--card,#16161c);border:1px solid var(--line);padding:0 0 0 16px;box-shadow:0 14px 30px rgba(0,0,0,.3)}
.bko-book::before{width:16px;background:linear-gradient(90deg,rgba(0,0,0,.45),rgba(128,128,128,.18))}
.bko-flap{display:none}
.bko-pages{border:0;background:transparent;box-shadow:none;padding:18px 16px}
.toc-hd{display:flex;align-items:center;gap:12px;margin:2px 0 12px}
.toc-hd .bki{font-size:1.9rem;margin:0;filter:none}
.toc-hd h3{font-size:1.15rem;margin:0}
.toc-sub{font-size:.78rem;opacity:.7;margin-top:2px}.toc-hd>div{flex:1;min-width:0}
.toc-l{margin-top:10px}
.toc{display:flex;align-items:flex-end;gap:8px;width:100%;padding:12px 4px;background:none;border:0;border-bottom:1px solid var(--line);color:var(--tx);font-family:inherit;text-align:left;cursor:pointer;transition:background .2s,padding .2s}
.toc:hover{background:color-mix(in srgb,var(--tx) 5%,transparent);padding-left:10px}
.toc .tn{font-weight:800;opacity:.5;min-width:30px;font-size:.85rem}
.toc .tt{font-weight:600;font-size:.98rem;line-height:1.5;flex:0 1 auto;min-width:0}
.toc .td{flex:1;min-width:14px;align-self:flex-end;margin-bottom:.45em;border-bottom:2px dotted color-mix(in srgb,var(--tx) 30%,transparent)}
.toc .tp{font-size:.78rem;font-weight:800;white-space:nowrap;opacity:.8}
.toc.full .tp{color:var(--ok);opacity:1}
.toc .pd{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px;flex:none;align-self:center}
.xb.tc{background:none;border-color:var(--line)}
.xb.tc .xb-star{background:color-mix(in srgb,var(--tx) 12%,transparent);color:var(--tx)}
.xb.tc .xb-pl{color:var(--tx);opacity:.75}
.cd-sub{font-size:.78rem;font-weight:700;opacity:.7;margin-bottom:4px}
.cd-h{font-size:1.35rem;line-height:1.4;margin:0 0 12px}
.cd-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:14px 0}
.cd-c{padding:10px 12px;border-radius:12px;border:1px solid var(--line);background:color-mix(in srgb,var(--tx) 4%,transparent)}
.cd-c small{display:block;opacity:.65;font-size:.72rem;margin-bottom:3px}.cd-c b{font-size:.92rem}
.xr{border-radius:12px;padding:12px;margin-bottom:8px;background:color-mix(in srgb,var(--tx,#fff) 4%,transparent);border:1px solid var(--line);border-left:3px solid var(--rc,var(--a1))}
.xr.full{border-left-color:var(--ok);opacity:.8}
.xr-n{display:flex;align-items:flex-start;gap:10px;margin-bottom:10px}
.xr-n b{font-size:.95rem;line-height:1.45;font-weight:700}
.xr-tag{font-size:.7rem;opacity:.7;margin-bottom:4px}
.xb{border-radius:16px;border:1px solid color-mix(in srgb,var(--bc) 42%,var(--line));background:linear-gradient(160deg,color-mix(in srgb,var(--bc) 10%,transparent),transparent 65%);margin-bottom:14px;overflow:hidden}
.xb-h{display:flex;align-items:center;gap:12px;padding:12px 14px}
.xb.done .xb-h{cursor:pointer}
.xb-star{min-width:58px;height:42px;padding:0 10px;border-radius:12px;display:grid;place-items:center;font-weight:900;font-size:1.05rem;color:#14110a;background:var(--bc);white-space:nowrap}
.xb-t{flex:1;min-width:0}.xb-t b{display:block}
.xb-pap{padding:0 14px 8px}
.xb-pl{display:flex;align-items:center;gap:8px;margin:12px 0 8px;font-size:.78rem;font-weight:800;color:var(--bc);letter-spacing:.04em}
.xb-pl::after{content:"";flex:1;height:1px;background:color-mix(in srgb,var(--bc) 38%,transparent)}
.xb-lock{text-align:center;padding:12px;border-radius:12px;border:1px dashed var(--line);opacity:.75;font-size:.85rem}
.xq-g{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}
.xq-c{position:relative;border:0;border-radius:18px;padding:18px 14px 14px;text-align:left;cursor:pointer;color:#fff;font-family:inherit;min-height:140px;display:flex;flex-direction:column;gap:6px;overflow:hidden;background:linear-gradient(150deg,color-mix(in srgb,var(--c) 46%,#16161e),color-mix(in srgb,var(--c) 14%,#0a0a0f));box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--c) 52%,transparent),0 8px 20px rgba(0,0,0,.3);transition:transform .25s}
.xq-c:hover{transform:translateY(-3px)}
.xq-c i{font-style:normal;font-size:2.1rem;line-height:1}
.xq-c b{font-size:1.15rem;font-weight:800}
.xq-c small{opacity:.9;margin-bottom:auto}
.xq-top{display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap}
.xq-ti{flex:1;display:flex;align-items:center;gap:8px;min-width:120px}
.xq-ti i{font-style:normal;font-size:1.5rem}.xq-ti b{font-size:1.05rem}
.xq-seg{margin-bottom:12px}
`;document.head.appendChild(st)})();

/* names: match NCTB spelling */
const BIOB=[
 {id:'b5',t:'5★',s:'সবচেয়ে গুরুত্বপূর্ণ',c:'#ffd166',p:[['bio1',[1,4,9,11]],['bio2',[2,4,11]]]},
 {id:'b3',t:'3★',s:'গুরুত্বপূর্ণ',c:'#7dd3fc',p:[['bio1',[3,5]],['bio2',[1,7,8]]]},
 {id:'b2',t:'2★',s:'মোটামুটি গুরুত্বপূর্ণ',c:'#c4a3ff',p:[['bio1',[2,7,8,10]],['bio2',[3,5,6]]]},
 {id:'b0',t:'Not imp',s:'কম গুরুত্বপূর্ণ',c:'#9ca3af',p:[['bio1',[6,12]],['bio2',[9,12]]]},
 {id:'bx',t:'বাকি',s:'তালিকায় ছিল না',c:'#fb923c',p:[['bio2',[10]]]}];
const PAPN={1:'১ম পত্র',2:'২য় পত্র'},PAPB={bio1:'১ম পত্র · উদ্ভিদবিজ্ঞান',bio2:'২য় পত্র · প্রাণিবিজ্ঞান'};
const XQ_SUB=[
 {k:'bio',bn:'জীববিজ্ঞান',t:'Biology',ic:'🧬',c:'#4ade80',keys:['bio1','bio2']},
 {k:'bangla',bn:'বাংলা',t:'Bangla',ic:'📖',c:'#ff8fab',keys:['bangla1','bangla2']},
 {k:'english',bn:'ইংরেজি',t:'English',ic:'🔤',c:'#7dd3fc',keys:['english1','english2']},
 {k:'ict',bn:'আইসিটি',t:'ICT',ic:'💻',c:'#fbbf24',keys:['ict']}];
const exFull=(k,i)=>(S.ex[k+'.'+i]||[]).filter(Boolean).length===4;
const bioItems=b=>{const o=[];b.p.forEach(([k,a])=>a.forEach(n=>o.push([k,n-1])));return o};
const bioDone=b=>bioItems(b).every(([k,i])=>exFull(k,i));
const subStat=s=>{let n=0,d=0;s.keys.forEach(k=>EXTRA[k][1].forEach((_,i)=>{n++;if(exFull(k,i))d++}));return{n,d,p:n?Math.round(d/n*100):0}};
const scEl=e=>{while(e&&e!==document.body){if(e.scrollHeight>e.clientHeight+2&&/(auto|scroll)/.test(getComputedStyle(e).overflowY))return e;e=e.parentElement}return null};
function xRowB(k,i,c,tag){const a=S.ex[k+'.'+i]||[0,0,0,0];return`<div class="xr ${exFull(k,i)?'full':''}" style="--rc:${c||'var(--a1)'}">${tag?`<div class="xr-tag">${esc(tag)}</div>`:''}<div class="xr-n"><span class="bkn">${bnum(i+1)}</span><b>${esc(EXTRA[k][1][i])}</b></div><div class="tasks">${TL.map((_,x)=>tbtn(k+'.'+i,x,a[x],'xt')).join('')}</div></div>`}
function bioBlocks(q,toc){q=(q||'').toLowerCase();const rw=(k,i,c,t)=>toc?tocEx(k,i,i+1):xRowB(k,i,c,t);
 if(q){let h='';BIOB.forEach(b=>b.p.forEach(([k,a])=>a.forEach(n=>{const i=n-1;if((b.t+' '+EXTRA[k][1][i]+' '+PAPB[k]+' bio biology জীববিজ্ঞান').toLowerCase().includes(q))h+=rw(k,i,b.c,b.t+' · '+PAPB[k])})));return h||'<div class="empty">Nothing found 🔍</div>'}
 const cur=BIOB.findIndex(b=>!bioDone(b)),op=UI.xbo||(UI.xbo=new Set());let h='',rest=0;
 BIOB.forEach((b,bi)=>{if(cur>=0&&bi>cur){rest++;return}
  const it=bioItems(b),d=it.filter(([k,i])=>exFull(k,i)).length,done=d===it.length;
  h+=`<section class="xb ${done?'done':''} ${toc?'tc':''}" style="--bc:${b.c}"><div class="xb-h" ${done?`data-act="xbTog" data-k="${b.id}"`:''}><span class="xb-star">${b.t}</span><div class="xb-t"><b>${esc(b.s)}</b><span class="mut sm">${bnum(d)}/${bnum(it.length)} chapter${done?' · ✓ সম্পন্ন':''}</span></div><span class="chip ${done?'ok':'a'}">${done?'✓':Math.round(d/it.length*100)+'%'}</span></div>`;
  if(!done||op.has(b.id)){h+='<div class="xb-pap">';b.p.forEach(([k,a])=>{h+=`<div class="xb-pl">${PAPB[k]}</div>`+a.map(n=>rw(k,n-1,b.c)).join('')});h+='</div>'}
  h+='</section>'});
 if(cur<0)h+='<div class="empty">🎉 সব Bio chapter শেষ!</div>';
 else if(rest)h+=`<div class="xb-lock">🔒 আরও ${bnum(rest)}টি ব্লক বাকি — এই ব্লক শেষ হলেই পরেরটা খুলবে</div>`;
 return h}

/* Extra tab: one Biology book (block-wise) instead of bio1 + bio2 */
{const _bi=bkItems;bkItems=function(){const o=_bi();if(UI.cseg==='core')return o;
 const q=(UI.q||'').toLowerCase(),out=o.filter(x=>x.k!=='bio1'&&x.k!=='bio2'),all=[];BIOB.forEach(b=>all.push(...bioItems(b)));
 const d=all.filter(([k,i])=>exFull(k,i)).length;
 const hit=!q||'bio biology জীববিজ্ঞান'.includes(q)||all.some(([k,i])=>(EXTRA[k][0]+' '+EXTRA[k][1][i]).toLowerCase().includes(q));
 out.push({k:'bio',t:'জীববিজ্ঞান',e:'',c:'#4ade80',ic:'🧬',n:all.length,done:d,pct:all.length?d/all.length*100:0,rows:hit?[0]:[],cnt:hit?1:0,list:[],bio:1});return out};
 const _br=bkRows;bkRows=function(it){return it.bio?bioBlocks(UI.q,true):_br(it)}}

/* Extra quest: 4 blocks -> chapters */
UI.xq={sub:'',pap:1};
function xqBody(){const x=UI.xq;
 if(!x.sub)return`<h2>🎯 Extra Quest</h2><div class="mut sm">কোনটা পড়লে? একটা বেছে নাও</div><div class="xq-g">${XQ_SUB.map(s=>{const t=subStat(s);return`<button class="xq-c" style="--c:${s.c}" data-act="xqSub" data-k="${s.k}"><i>${s.ic}</i><b>${s.bn}</b><small>${s.t} · ${bnum(t.d)}/${bnum(t.n)}</small>${bar(t.p,s.c)}</button>`}).join('')}</div>`;
 const s=XQ_SUB.find(z=>z.k===x.sub),t=subStat(s);let inner='';
 if(s.k==='bio')inner=bioBlocks('');
 else{const k=s.keys[x.pap-1]||s.keys[0];
  if(s.keys.length>1)inner=`<div class="seg xq-seg">${s.keys.map((kk,n)=>`<button class="${kk===k?'on':''}" data-act="xqPap" data-k="${n+1}">${PAPN[n+1]}</button>`).join('')}</div>`;
  inner+=EXTRA[k][1].map((_,i)=>xRowB(k,i,s.c)).join('')}
 return`<div class="xq-top"><button class="btn g s" data-act="xqBack">‹ ফিরে যাও</button><span class="xq-ti"><i>${s.ic}</i><b>${s.bn}</b></span><span class="chip a">${t.p}%</span></div>${inner}<button class="btn p" style="width:100%;margin-top:14px" data-act="close">Done</button>`}
function xqRender(){const m=$('#xqm');if(!m)return;const sc=scEl(m),y=sc?sc.scrollTop:0;m.innerHTML=xqBody();if(sc)sc.scrollTop=y}
{const _xt=ACT.xt;Object.assign(ACT,{
 xq:()=>{UI.xq={sub:'',pap:1};modal('<div id="xqm"></div>',true);xqRender()},
 xqSub:el=>{UI.xq.sub=el.dataset.k;UI.xq.pap=1;xqRender();const sc=scEl($('#xqm'));if(sc)sc.scrollTop=0},
 xqBack:()=>{UI.xq.sub='';xqRender()},
 xqPap:el=>{UI.xq.pap=+el.dataset.k;xqRender()},
 xbTog:el=>{const s=UI.xbo||(UI.xbo=new Set()),k=el.dataset.k;s.has(k)?s.delete(k):s.add(k);if($('#xqm'))xqRender();else render(false)},
 xt:(el,e)=>{_xt(el,e);if($('#xqm'))xqRender()}})}

