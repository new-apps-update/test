Object.assign(ACT,{
 pendGo:()=>{closeModal();go('today');window.scrollTo({top:0,behavior:'smooth'})},
 cf:el=>{UI.cf=el.dataset.k;render(false)},
 clGo:el=>{const l=(gc(el.dataset.ch).cl||[])[+el.dataset.k];if(!l)return;closeSheet();openExt(fixUrl(l.url))},
 clEdit:el=>{closeSheet();clModal(el.dataset.ch)},
 clAdd2:()=>{const u=$('#clu').value.trim();if(!u)return;const c=gc(UI.clid);(c.cl=c.cl||[]).push({name:$('#cln').value.trim(),url:u});save();clModal(UI.clid)},
 clDel:el=>{const c=gc(UI.clid);(c.cl||[]).splice(+el.dataset.k,1);save();clModal(UI.clid)},
 whyM:el=>{S.set.whyMode=el.dataset.k;save();render(false)},
 whyG:el=>{S.set.whyGap=+el.dataset.k;save();render(false)}});

