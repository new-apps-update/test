(function boot(){
 document.documentElement.style.setProperty('--fs',S.set.fs+'px');document.body.classList.toggle('calm',!!S.set.calm);applyTheme();applyIcon();bgSize();bgStart();
 const p=location.hash.replace('#/','');UI.page=PAGES[p]?p:'today';render(true);
 const cp=cloudInit();
 if(!S.onb){if(FB_CONFIG.databaseURL)Promise.race([cp,new Promise(r=>setTimeout(r,3500))]).then(()=>{S.onb?splash():onboard()});else onboard()}else splash();
 if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
 setInterval(()=>{const t=today();if(boot.d&&boot.d!==t)render(false);boot.d=t},60000);boot.d=today();
})();
