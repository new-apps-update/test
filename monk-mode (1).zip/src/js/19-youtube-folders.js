/* ===== v7: YouTube folders — audio only, hidden player ===== */
const YP={on:0,paused:1,q:[],qi:0,fid:'',p:null,pp:null,ld:null,nt:'',err:0,ut:0,warm:0,bt:0};
const YD=()=>S.ytf||(S.ytf={f:[],sel:'',last:''}),ytSv=()=>save(),fOf=id=>YD().f.find(x=>x.id===id);
const ytT=()=>{try{return YP.p.getCurrentTime()||0}catch(e){return 0}},ytDur=()=>{try{return YP.p.getDuration()||0}catch(e){return 0}},ytSeek=v=>{try{YP.p.seekTo(v,true)}catch(e){}},ytPause=()=>{try{YP.p.pauseVideo()}catch(e){}},ytResume=()=>{try{YP.p.playVideo()}catch(e){}},ytEv=n=>{try{AU.dispatchEvent(new Event(n))}catch(e){}};
const _ap=AU.pause.bind(AU);
{const g=n=>Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,n),dP=g('paused'),dT=g('currentTime'),dD=g('duration'),dS=g('src');
 Object.defineProperties(AU,{
  paused:{configurable:true,get(){return YP.on?!!YP.paused:dP.get.call(AU)}},
  currentTime:{configurable:true,get(){return YP.on?ytT():dT.get.call(AU)},set(v){YP.on?ytSeek(v):dT.set.call(AU,v)}},
  duration:{configurable:true,get(){return YP.on?ytDur():dD.get.call(AU)}},
  src:{configurable:true,get(){return YP.on?'yt:'+YP.fid:dS.get.call(AU)},set(v){dS.set.call(AU,v)}}});
 AU.pause=()=>YP.on?ytPause():_ap();}
/* the browser cannot read YouTube's audio, so visuals get a beat-synced simulated spectrum */
const FAKE={getByteFrequencyData(a){const t=performance.now()/1000,bt=Math.pow(Math.max(0,Math.sin(t*Math.PI*2*1.9)),6),e=.6+.4*Math.sin(t*.7),n=a.length;for(let i=0;i<n;i++){const r=Math.sin(t*(2+i*.13)+i*1.7)*.5+.5,k=1-i/n;a[i]=Math.min(255,(r*.55+bt*.55*k)*255*e*(.45+.55*k))}},
 getByteTimeDomainData(a){const t=performance.now()/1000,e=.5+.5*Math.sin(t*1.9);for(let i=0;i<a.length;i++)a[i]=128+Math.sin(t*5+i*.25)*42*e}};
{const _a=mzAn;mzAn=function(){if(YP.on)return;if(MZ.ctx){MZ.an=MZ.ran||MZ.an;return}_a();MZ.ran=MZ.an}}
{const _m=mzPlay;mzPlay=function(i){ytOff();return _m(i)}}
{const b=document.createElement('div');b.id='ytbox';b.innerHTML='<div id="ytp"></div>';document.body.appendChild(b)}
const ytAPI=()=>YP.ld||(YP.ld=new Promise((ok,no)=>{if(window.YT&&window.YT.Player)return ok();const pr=window.onYouTubeIframeAPIReady;window.onYouTubeIframeAPIReady=()=>{try{pr&&pr()}catch(e){}ok()};const s=document.createElement('script');s.src='https://www.youtube.com/iframe_api';s.onerror=()=>{YP.ld=null;no(new Error('net'))};document.head.appendChild(s)}));
const ytEnsure=()=>YP.pp||(YP.pp=ytAPI().then(()=>new Promise(ok=>{const v={autoplay:1,controls:0,playsinline:1,rel:0,disablekb:1,fs:0,iv_load_policy:3,modestbranding:1};if(/^https?:/.test(location.protocol))v.origin=location.origin;
 YP.p=new window.YT.Player('ytp',{width:240,height:135,playerVars:v,events:{onReady:()=>{try{YP.p.setVolume(MZ.vol*100)}catch(e){}ok(YP.p)},onStateChange:ytState,onError:ytErr}})})).catch(e=>{YP.pp=null;YP.ld=null;throw e}));
const ytWarm=()=>{if(YP.warm)return;YP.warm=1;ytEnsure().catch(()=>{YP.warm=0})};
const ytIt=()=>YP.q[YP.qi],ytName=()=>{const it=ytIt();return YP.nt||(it&&it.t)||'YouTube'},ytFn=()=>{const f=fOf(YP.fid);return f?f.name:''};
function ytTake(){try{_ap()}catch(e){}YP.on=1;MZ.an=FAKE}
function ytOff(){if(!YP.on)return;YP.on=0;YP.paused=1;clearTimeout(YP.bt);try{YP.p&&YP.p.stopVideo()}catch(e){}MZ.an=MZ.ran||null}
function ytMS(){if(!('mediaSession' in navigator)||!YP.on)return;try{const m=navigator.mediaSession;m.metadata=new MediaMetadata({title:ytName(),artist:ytFn()||'YouTube',album:'Monk Mode'});m.setActionHandler('play',()=>ACT.mzTog());m.setActionHandler('pause',()=>ACT.mzTog());m.setActionHandler('nexttrack',()=>ACT.mzNext());m.setActionHandler('previoustrack',()=>ACT.mzPrev())}catch(e){}}
async function ytPlayAt(i){const it=YP.q[i];if(!it)return;YP.qi=i;YP.nt='';ytTake();YP.paused=0;mzUI();
 try{const p=await ytEnsure();if(!YP.on||YP.q[YP.qi]!==it)return;it.k==='p'?p.loadPlaylist({list:it.v,listType:'playlist',index:0}):p.loadVideoById(it.v);p.setVolume(MZ.vol*100);ytMS();
  clearTimeout(YP.bt);YP.bt=setTimeout(()=>{try{if(YP.on&&[-1,5,2].includes(p.getPlayerState())&&!(p.getCurrentTime()>0)){YP.paused=1;ytEv('pause');toast('Tap ▶ to start — the browser blocked autoplay')}}catch(e){}},3500)}
 catch(e){YP.on=0;YP.paused=1;toast('YouTube could not load — check your internet connection','bad');mzUI()}}
function ytPlayF(fid,shuf,start){const f=fOf(fid);if(!f||!f.items.length)return toast('Add some links to this folder first','bad');const q=f.items.slice();let si=0;
 if(shuf)for(let i=q.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[q[i],q[j]]=[q[j],q[i]]}else if(start>0)si=start;
 YP.q=q;YP.fid=fid;YP.err=0;YD().last=fid;ytSv();ytPlayAt(si)}
function ytStep(d){const n=YP.q.length;if(!n)return;const it=ytIt();
 if(it&&it.k==='p'&&YP.p){try{const l=YP.p.getPlaylist()||[],i=YP.p.getPlaylistIndex();if(d>0&&i<l.length-1){YP.p.nextVideo();return}if(d<0&&i>0){YP.p.previousVideo();return}}catch(e){}}
 ytPlayAt((YP.qi+d+n)%n)}
function ytState(e){if(!YP.on||!window.YT)return;const P=window.YT.PlayerState,s=e.data;
 if(s===P.PLAYING){YP.paused=0;YP.err=0;clearTimeout(YP.bt);try{const d=YP.p.getVideoData();if(d&&d.title){YP.nt=d.title;const it=ytIt();if(it&&it.k==='v'&&!it.t){it.t=d.title;ytSv()}}}catch(x){}ytMS();ytEv('play');ytEv('loadedmetadata')}
 else if(s===P.PAUSED){YP.paused=1;ytEv('pause')}
 else if(s===P.ENDED){const it=ytIt();if(it&&it.k==='p'){try{if(YP.p.getPlaylistIndex()<(YP.p.getPlaylist()||[]).length-1)return}catch(x){}}ytStep(1)}}
function ytErr(e){if(!YP.on)return;YP.err++;toast('Skipped a video that cannot be played','bad');if(YP.err>YP.q.length){ytOff();YP.err=0;mzUI();return}setTimeout(()=>YP.on&&ytStep(1),500)}
setInterval(()=>{if(YP.on&&!YP.paused)ytEv('timeupdate')},500);
/* links */
function ytParse(u){u=(u||'').trim();if(!u)return null;const id=/^[\w-]{11}$/;if(id.test(u))return{k:'v',v:u};
 try{const x=new URL(/^https?:\/\//i.test(u)?u:'https://'+u),h=x.hostname.replace(/^(www|m|music)\./,''),V=x.searchParams.get('v'),L=x.searchParams.get('list');
  if(h==='youtu.be'){const a=x.pathname.split('/')[1]||'';return id.test(a)?{k:'v',v:a}:null}
  if(h==='youtube.com'||h==='youtube-nocookie.com'){if(V&&id.test(V))return{k:'v',v:V};const m=x.pathname.match(/^\/(?:shorts|embed|live|v)\/([\w-]{11})/);if(m)return{k:'v',v:m[1]};if(L&&/^[\w-]{10,}$/.test(L))return{k:'p',v:L}}}catch(e){}return null}
async function ytMeta(it){try{const u=it.k==='p'?'https://www.youtube.com/playlist?list='+it.v:'https://www.youtube.com/watch?v='+it.v,r=await fetch('https://www.youtube.com/oembed?format=json&url='+encodeURIComponent(u));if(!r.ok)return;const j=await r.json();if(j.title){it.t=j.title;ytSv();mzUI()}}catch(e){}}
/* ui */
const EQ='<span class="yteq"><u></u><u></u><u></u></span>';
function ytCard(){const D=YD(),F=D.f,sel=F.find(x=>x.id===D.sel),play=YP.on&&!YP.paused;
 const rows=F.map(f=>{const cur=YP.on&&YP.fid===f.id;return`<div class="ytf ${f.id===D.sel?'sel':''} ${cur?'cur':''}" data-act="ytSel" data-k="${f.id}"><i class="ytfi">${cur&&play?EQ:'📁'}</i><div class="ytfn"><b>${esc(f.name)}</b><small>${f.items.length} link${f.items.length===1?'':'s'}</small></div><button class="ytb" data-act="ytPlay" data-k="${f.id}" title="Play folder" aria-label="Play folder">▶</button></div>`}).join('');
 let det='';
 if(sel)det=`<div class="ytd"><div class="row sp wrap" style="gap:8px"><b>${esc(sel.name)}</b><div class="row" style="gap:6px"><button class="btn p s" data-act="ytPlay" data-k="${sel.id}">▶ Play</button><button class="btn g s" data-act="ytShuf" data-k="${sel.id}" title="Shuffle">🔀</button><button class="btn g s" data-act="ytRen" data-k="${sel.id}" title="Rename">✎</button><button class="btn d s" data-act="ytDelF" data-k="${sel.id}" title="Delete folder">🗑</button></div></div>
<div class="ytadd"><input class="field" id="ytIn" placeholder="Paste a YouTube video or playlist link…" data-enter="ytAdd" autocomplete="off" inputmode="url"><button class="btn p" data-act="ytAdd">＋ Add</button></div>
<div class="mzl" style="margin:10px 0 0">${sel.items.map((it,i)=>{const c=YP.on&&YP.fid===sel.id&&ytIt()&&ytIt().id===it.id;return`<div class="mzi ${c?'on':''}" data-act="ytPlayI" data-f="${sel.id}" data-i="${i}"><span>${c&&play?EQ:i+1}</span><b>${esc(it.t||(it.k==='p'?'YouTube playlist':'YouTube video')+' · '+it.v)}${it.k==='p'?'<em class="ytpl">PLAYLIST</em>':''}</b><button data-act="ytRm" data-f="${sel.id}" data-i="${i}" title="Remove">✕</button></div>`}).join('')||'<div class="empty">Folder is empty — paste links above, one at a time. They play in this order.</div>'}</div></div>`;
 return`<section class="card rise" style="${ri()}"><div class="row sp" style="margin-bottom:12px"><div><h3>▶ YouTube folders</h3><div class="mut sm">Audio only — the video never shows</div></div><button class="btn g s" data-act="ytNew">＋ Folder</button></div>${F.length?`<div class="ytfl">${rows}</div>`:'<div class="empty">Create a folder, add YouTube links, then play the whole folder.</div>'}${det}</section>`}
const ytMini=()=>{const F=YD().f;return`<div class="mzl2">YouTube folders</div>`+(F.length?`<div class="ytmini">${F.map(f=>`<button class="${YP.on&&YP.fid===f.id?'on':''}" data-act="ytPlay" data-k="${f.id}">▶ ${esc(f.name)} <small>${f.items.length}</small></button>`).join('')}</div>`:'<div class="mut sm">No folders yet — create one in the Music section.</div>')+`<button class="btn g s" style="margin-top:12px;width:100%" data-act="mzSec">Open Music section ↗</button>`};
{const _w=mzWs;mzWs=function(){let h=_w();h=h.replace('<h3>🎶 Playlist</h3>','<h3>💿 Uploaded songs</h3>');const i=h.indexOf('<h3>💿 Uploaded songs'),j=i<0?-1:h.lastIndexOf('<section',i);if(j>0)h=h.slice(0,j)+ytCard()+h.slice(j);if(YD().f.some(f=>f.items.length))setTimeout(ytWarm,300);return h}}
{const _p=mzPanel;mzPanel=function(){return _p()+ytMini()}}
{const _c=mzCtl;mzCtl=st=>{let h=_c(st);if(YP.on)h=h.replace(/<div class="mzn">[\s\S]*?<\/div>/,`<div class="mzn">${esc(ytName())}<small class="ytsub">▶ ${esc(ytFn())}</small></div>`);else h=h.replace('upload from your PC','add songs or YouTube links');return h}}
function mzUI(){clearTimeout(YP.ut);YP.ut=setTimeout(()=>{const e=$('#ytIn'),v=e?e.value:'',fc=e&&document.activeElement===e,pg=$('#page');pg&&pg.classList.remove('anim');mzUI_o();mzfVis();const n=$('#ytIn');if(n&&v){n.value=v;if(fc)n.focus()}},30)}
/* floating disc → satellite shortcut to the Music section */
{const g=document.createElement('button');g.id='mzg';g.dataset.act='mzSec';g.title='Open Music section';g.setAttribute('aria-label','Open Music section');g.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg><span>Music section</span><em>↗</em>';document.body.appendChild(g)}
const ytIn=()=>setTimeout(()=>{const i=$('#ytIn');i&&i.focus()},60);
Object.assign(ACT,{
 mzSec:()=>{$('#mzp').classList.remove('open');UI.space='music';go('space')},
 mzTog:(()=>{const o=ACT.mzTog;return el=>{if(YP.on){YP.paused?ytResume():ytPause();return}if(!MZ.list.length){const D=YD(),f=fOf(D.last)||fOf(D.sel);if(f&&f.items.length)return ytPlayF(f.id)}o(el)}})(),
 mzNext:()=>YP.on?ytStep(1):mzPlay(MZ.idx+1),mzPrev:()=>YP.on?ytStep(-1):mzPlay(MZ.idx-1),
 ytNew:()=>{modal(`<h2>📁 New folder</h2><p class="mut sm" style="margin-bottom:12px">Name it anything — YouTube, Lo-fi, Focus…</p><input class="field" id="ytfn" maxlength="40" placeholder="Folder name" data-enter="ytMk" autocomplete="off"><div class="row" style="gap:10px;margin-top:16px;justify-content:flex-end"><button class="btn g" data-act="close">Cancel</button><button class="btn p" data-act="ytMk">Create</button></div>`);setTimeout(()=>{const e=$('#ytfn');e&&e.focus()},80)},
 ytMk:()=>{const e=$('#ytfn'),n=e&&e.value.trim();if(!n)return toast('Enter a folder name','bad');const D=YD(),f={id:uid(),name:n,items:[]};D.f.push(f);D.sel=f.id;ytSv();closeModal();mzUI();toast('Folder created','ok');ytIn()},
 ytRen:el=>{const f=fOf(el.dataset.k);if(!f)return;modal(`<h2>✎ Rename folder</h2><input class="field" id="ytfr" data-k="${f.id}" maxlength="40" value="${esc(f.name)}" data-enter="ytRenOk" autocomplete="off" style="margin-top:8px"><div class="row" style="gap:10px;margin-top:16px;justify-content:flex-end"><button class="btn g" data-act="close">Cancel</button><button class="btn p" data-act="ytRenOk">Save</button></div>`);setTimeout(()=>{const e=$('#ytfr');e&&(e.focus(),e.select())},80)},
 ytRenOk:()=>{const e=$('#ytfr'),f=e&&fOf(e.dataset.k),n=e&&e.value.trim();if(!f||!n)return toast('Enter a folder name','bad');f.name=n;ytSv();closeModal();mzUI()},
 ytDelF:el=>{const f=fOf(el.dataset.k);if(!f||!confirm('Delete folder "'+f.name+'" and its '+f.items.length+' link(s)?'))return;const D=YD();D.f=D.f.filter(x=>x.id!==f.id);if(D.sel===f.id)D.sel='';if(YP.fid===f.id){ytOff();YP.fid=''}ytSv();mzUI()},
 ytSel:el=>{const D=YD();D.sel=D.sel===el.dataset.k?'':el.dataset.k;ytSv();mzUI()},
 ytPlay:el=>ytPlayF(el.dataset.k,false,0),ytShuf:el=>ytPlayF(el.dataset.k,true),ytPlayI:el=>ytPlayF(el.dataset.f,false,+el.dataset.i),
 ytRm:el=>{const f=fOf(el.dataset.f);if(!f)return;f.items.splice(+el.dataset.i,1);ytSv();mzUI()},
 ytAdd:()=>{const e=$('#ytIn');if(!e)return;const D=YD();let f=fOf(D.sel);if(!f){if(D.f.length)return toast('Open a folder first','bad');f={id:uid(),name:'YouTube',items:[]};D.f.push(f);D.sel=f.id}
  const tk=e.value.split(/[\s,]+/).filter(Boolean);if(!tk.length)return toast('Paste a YouTube link first','bad');let ok=0,bad=0;
  tk.forEach(t=>{const p=ytParse(t);if(!p){bad++;return}if(f.items.some(i=>i.k===p.k&&i.v===p.v))return;const it={id:uid(),k:p.k,v:p.v,t:''};f.items.push(it);ok++;ytMeta(it)});
  if(ok){e.value='';ytSv();ytWarm()}
  toast(ok?ok+' link'+(ok>1?'s':'')+' added'+(bad?' · '+bad+' invalid':''):bad?'That is not a YouTube link':'Already in this folder',ok?'ok':'bad');mzUI();ytIn()}});
{const _v=IN.mzVol;IN.mzVol=e=>{_v(e);try{YP.p&&YP.p.setVolume(MZ.vol*100)}catch(x){}}}

