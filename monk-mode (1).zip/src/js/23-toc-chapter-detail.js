/* ===== table-of-contents book + chapter detail sheet ===== */
const tocRow=(act,t,k,n,name,cnt,dot)=>`<button class="toc ${cnt===4?'full':''}" data-act="cdOpen" data-t="${t}" data-k="${esc(k)}">${dot?`<i class="pd" style="background:${dot}"></i>`:''}<span class="tn">${bnum(n)}</span><span class="tt">${esc(name)}</span><i class="td"></i><span class="tp">${cnt===4?'✓':bnum(cnt)+'/৪'}</span></button>`;
let tocCore=(id,n)=>tocRow('cdOpen','c',id,n,CH[id].n,chN(id),prOf(id)?PRI[prOf(id)][1]:'');
let tocEx=(k,i,n)=>tocRow('cdOpen','x',k+'.'+i,n,EXTRA[k][1][i],(S.ex[k+'.'+i]||[]).filter(Boolean).length);
bkOpen=function(it,flap,back){const p=Math.round(it.pct);
 const rows=it.core?it.rows.map((id,x)=>tocCore(id,x+1)).join(''):it.bio?bioBlocks(UI.q,true):it.rows.map(i=>tocEx(it.k,i,i+1)).join('');
 return`<section class="bko ${back?'':'bko-sp'}" id="${back?'bko':'bko-'+it.k}" style="--c:${it.c}"><div class="bko-book"><div class="bko-pages">${back?'<div class="bko-h"><button class="btn g s" data-act="bkClose">‹ সব বই</button></div>':''}<div class="toc-hd"><span class="bki">${esc(it.ic)}</span><div><h3>${esc(it.t)}</h3><div class="toc-sub">সূচিপত্র · ${bnum(it.done)}/${bnum(it.n)} chapter সম্পন্ন</div></div><span class="chip a">${bnum(p)}%</span></div>${bar(it.pct)}<div class="toc-l">${rows||'<div class="empty">Nothing found 🔍</div>'}</div></div></div></section>`};
function cdBody(){const d=UI.cd;let sub,name,n,c,tasks,cells,top='',foot='';
 if(d.t==='c'){const id=d.k,ch=CH[id],sj=SUBJ[ch.s],st=gc(id);n=chN(id);c=sj.c;sub=sj.n;name=ch.n;
  tasks=TL.map((_,x)=>tbtn(id,x,st.t[x])).join('');
  cells=[['📅 পড়ার দিন',chRange(id)||'—'],['⏱ Class time',clTot(id)?fmM(clTot(id)):'—'],['✅ অবস্থা',n===4?'সম্পন্ন'+(st.done?' · '+fD(st.done):''):bnum(n)+'/৪ task']];
  top=`<div class="row" style="gap:10px;margin:8px 0 2px;flex-wrap:wrap">${tagChips(id)}<button class="star ${st.w?'on':''}" data-act="weak" data-k="${id}" title="Weak">★</button></div>`;
  foot=`<button class="btn g" style="width:100%;margin-top:10px" data-act="cdLinks" data-k="${id}">🔗 Class links / YouTube</button>`}
 else{const [g,i]=d.k.split('.'),a=S.ex[d.k]||[0,0,0,0];n=a.filter(Boolean).length;c=EXC[g]||'#6d8cff';sub=EXTRA[g][0];name=EXTRA[g][1][+i];
  tasks=TL.map((_,x)=>tbtn(d.k,x,a[x],'xt')).join('');
  cells=[['📘 বইয়ের chapter',bnum(+i+1)],['📚 পত্র',PAPB[g]||EXTRA[g][0]]];
  if(g==='bio1'||g==='bio2'){const b=BIOB.find(b=>b.p.some(([kk,arr])=>kk===g&&arr.includes(+i+1)));if(b)cells.push(['⭐ গুরুত্ব',b.t+' · '+b.s])}
  cells.push(['✅ অবস্থা',n===4?'সম্পন্ন':bnum(n)+'/৪ task'])}
 return`<div class="cd-sub" style="color:${c}">${esc(sub)}</div><h2 class="cd-h">${esc(name)}</h2>${bar(n*25,c)}<div class="cd-g">${cells.map(x=>`<div class="cd-c"><small>${x[0]}</small><b>${esc(x[1])}</b></div>`).join('')}</div>${top}<label class="l" style="margin-top:12px;display:block">Progress</label><div class="tasks">${tasks}</div>${foot}<button class="btn p" style="width:100%;margin-top:14px" data-act="close">Close</button>`}
function cdRender(){const m=$('#cdm');if(!m)return;const sc=scEl(m),y=sc?sc.scrollTop:0;m.innerHTML=cdBody();if(sc)sc.scrollTop=y}
Object.assign(ACT,{cdOpen:el=>{UI.cd={t:el.dataset.t,k:el.dataset.k};modal('<div id="cdm"></div>');cdRender()},cdLinks:el=>{closeModal();ACT.chOpen(el)}});
['tt','weak','xt'].forEach(a=>{const f=ACT[a];ACT[a]=(el,e)=>{f(el,e);if($('#cdm'))cdRender()}});

