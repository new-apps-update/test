/* ===== book-style chapters + full fresh start ===== */
(()=>{const st=document.createElement('style');st.textContent=`
.bks{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:22px 16px;padding:6px 2px 10px}
.bkc{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:space-between;text-align:center;aspect-ratio:3/4;padding:16px 12px 14px 22px;border:0;color:#fff;cursor:pointer;font-family:inherit;border-radius:6px 12px 12px 6px;background:linear-gradient(135deg,color-mix(in srgb,var(--c) 88%,#fff 12%),color-mix(in srgb,var(--c) 62%,#000 38%));box-shadow:0 10px 22px rgba(0,0,0,.38),inset 0 0 0 1px rgba(255,255,255,.14);transition:transform .35s cubic-bezier(.2,.8,.2,1),box-shadow .35s;animation:bkIn .5s both;transform-origin:left center}
.bkc::before{content:"";position:absolute;left:0;top:0;bottom:0;width:13px;border-radius:6px 0 0 6px;background:linear-gradient(90deg,rgba(0,0,0,.5),rgba(0,0,0,.12) 60%,rgba(255,255,255,.14));box-shadow:2px 0 5px rgba(0,0,0,.25)}
.bkc::after{content:"";position:absolute;right:-4px;top:5px;bottom:5px;width:5px;border-radius:0 4px 4px 0;background:repeating-linear-gradient(180deg,#f4ecd8 0 2px,#d9cfb5 2px 3px)}
.bkc:hover{transform:perspective(700px) rotateY(-14deg) translateY(-5px);box-shadow:0 18px 30px rgba(0,0,0,.45),inset 0 0 0 1px rgba(255,255,255,.2)}
.bkc.on{outline:2px solid var(--a1);outline-offset:3px}
.bkf{position:absolute;inset:10px 9px 10px 20px;border:1.5px solid rgba(255,255,255,.35);border-radius:4px;pointer-events:none}
.bki{font-size:2.1rem;margin-top:8px;filter:drop-shadow(0 3px 4px rgba(0,0,0,.4));z-index:1}
.bkt{font-weight:700;font-size:.92rem;line-height:1.25;z-index:1;text-shadow:0 1px 3px rgba(0,0,0,.45);padding:0 4px}
.bkm{z-index:1;width:100%;font-size:.7rem;opacity:.95}
.bkm i{display:block;height:4px;border-radius:3px;background:rgba(0,0,0,.35);margin-top:5px;overflow:hidden}
.bkm i b{display:block;height:100%;background:#fff;border-radius:3px}
.bkr{position:absolute;top:-2px;right:16px;width:14px;height:30px;background:var(--a1);clip-path:polygon(0 0,100% 0,100% 100%,50% 78%,0 100%);z-index:2}
.bko{position:relative;margin-bottom:14px;perspective:1400px;animation:bkOp .45s both}
.bko.closing{animation:bkCl .3s both}
.bko-book{position:relative;border-radius:8px 16px 16px 8px;background:linear-gradient(135deg,color-mix(in srgb,var(--c) 85%,#fff 15%),color-mix(in srgb,var(--c) 55%,#000 45%));padding:10px 10px 10px 22px;box-shadow:0 16px 36px rgba(0,0,0,.42)}
.bko-book::before{content:"";position:absolute;left:0;top:0;bottom:0;width:14px;border-radius:8px 0 0 8px;background:linear-gradient(90deg,rgba(0,0,0,.5),rgba(0,0,0,.1))}
.bko-pages{position:relative;border-radius:4px 10px 10px 4px;background:var(--card,#16161c);border:1px solid var(--line);padding:16px 14px;box-shadow:inset 3px 0 8px rgba(0,0,0,.25)}
[data-light] .bko-pages{background:#fffdf6}
.bko-flap{position:absolute;inset:0;z-index:5;border-radius:8px 16px 16px 8px;transform-origin:left center;background:linear-gradient(135deg,color-mix(in srgb,var(--c) 85%,#fff 15%),color-mix(in srgb,var(--c) 55%,#000 45%));display:flex;align-items:center;justify-content:center;font-size:3rem;animation:flapO .9s .08s cubic-bezier(.5,0,.2,1) both;pointer-events:none;backface-visibility:hidden}
.bko-h{display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap}
.bko-h .bki{margin:0;font-size:1.9rem;filter:none}
.bko-r{display:flex;flex-direction:column;gap:12px;margin-top:14px}
.bkn{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:24px;border-radius:50%;background:var(--a1);color:#111;font-size:.72rem;font-weight:700;margin-right:8px;flex:none}
.bko-sp{margin-bottom:18px}
@keyframes bkIn{from{opacity:0;transform:translateY(16px) scale(.94)}to{opacity:1;transform:none}}
@keyframes bkOp{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:none}}
@keyframes bkCl{to{opacity:0;transform:scale(.94)}}
@keyframes flapO{0%{transform:rotateY(0);opacity:1}85%{opacity:1}100%{transform:rotateY(-170deg);opacity:0}}
.bkc:nth-child(2){animation-delay:.05s}.bkc:nth-child(3){animation-delay:.1s}.bkc:nth-child(4){animation-delay:.15s}.bkc:nth-child(5){animation-delay:.2s}.bkc:nth-child(6){animation-delay:.25s}.bkc:nth-child(n+7){animation-delay:.3s}
body.calm .bko-flap{display:none}body.calm .bkc,body.calm .bko{animation:none}
@media(hover:none){.bkc:hover{transform:none}}
@media(max-width:420px){.bks{grid-template-columns:repeat(2,1fr);gap:20px 14px}}
`;document.head.appendChild(st)})();
const BIC={C1:'⚗️',C2:'🧪',P1:'⚛️',P2:'💡',M1:'📐',M2:'∑'};
const bnum=n=>String(n).replace(/\d/g,x=>'০১২৩৪৫৬৭৮৯'[x]);
function bkItems(){const q=(UI.q||'').toLowerCase(),out=[];
 if(UI.cseg==='core'){Object.keys(SUBJ).forEach(k=>{const all=CHL[k]||[],ids=all.filter(i=>(!q||(SUBJ[k].n+CH[i].n+SUBJ[k].e).toLowerCase().includes(q))&&fpOk(i));const done=all.filter(i=>chN(i)===4).length;out.push({k,t:SUBJ[k].n,e:SUBJ[k].e,c:SUBJ[k].c,ic:BIC[k]||'📘',n:all.length,done,pct:all.length?all.reduce((a,i)=>a+chN(i),0)/(all.length*4)*100:0,rows:ids,cnt:ids.length,core:1})})}
 else{Object.keys(EXTRA).forEach(k=>{const[t,list]=EXTRA[k];const idx=list.map((n,i)=>i).filter(i=>!q||(t+list[i]).toLowerCase().includes(q));const done=list.filter((_,i)=>(S.ex[k+'.'+i]||[]).filter(Boolean).length===4).length;const m=String(t).match(/^(\S+)\s+(.*)$/);const hasE=m&&!/[A-Za-z0-9ঀ-৿]/.test(m[1]);out.push({k,t:hasE?m[2]:t,e:'',c:(typeof EXC!=='undefined'&&EXC[k])||'#6d8cff',ic:hasE?m[1]:'📕',n:list.length,done,pct:list.length?done/list.length*100:0,rows:idx,cnt:idx.length,list})})}
 return out}
function bkRows(it){return it.rows.map((i,x)=>it.core?coreRow(i,x+1):exRow(it.k,i,it.list,i+1)).join('')}
function coreRow(i,n){const st=gc(i);return`<div class="li cr ${chN(i)===4?'full':''}" data-ch="${i}" style="flex-direction:column;align-items:stretch;gap:10px;${prOf(i)?`border-left:3px solid ${PRI[prOf(i)][1]}`:''}"><div class="row sp"><div style="display:flex;align-items:flex-start"><span class="bkn">${bnum(n)}</span><div><b class="sm">${chName(i)}</b><div class="mut sm">${chRange(i)}${clTot(i)?' · ⏱ '+fmM(clTot(i)):''}</div><div class="tgs">${tagChips(i)}</div></div></div><button class="star ${st.w?'on':''}" data-act="weak" data-k="${i}">★</button></div><div class="cbar"><i style="width:${chN(i)*25}%"></i></div><div class="tasks">${TL.map((_,x)=>tbtn(i,x,st.t[x])).join('')}</div></div>`}
function exRow(k,i,list,n){const a=S.ex[k+'.'+i]||[0,0,0,0];return`<div class="li" style="flex-direction:column;align-items:stretch;gap:10px"><div style="display:flex;align-items:center"><span class="bkn">${bnum(n)}</span><b class="sm">${esc(list[i])}</b></div><div class="tasks">${TL.map((_,x)=>tbtn(k+'.'+i,x,a[x],'xt')).join('')}</div></div>`}
function bkCover(it){return`<button class="bkc ${UI.book===it.k?'on':''}" style="--c:${it.c}" data-act="bkOpen" data-k="${it.k}"><span class="bkf"></span>${it.pct>=100?'<span class="bkr"></span>':''}<span class="bki">${esc(it.ic)}</span><span class="bkt">${esc(it.t)}</span><span class="bkm">${it.done}/${it.n} chapters<i><b style="width:${Math.round(it.pct)}%"></b></i></span></button>`}
function bkOpen(it,flap,back){return`<section class="bko ${back?'':'bko-sp'}" id="${back?'bko':'bko-'+it.k}" style="--c:${it.c}"><div class="bko-book">${flap?`<div class="bko-flap">${esc(it.ic)}</div>`:''}<div class="bko-pages"><div class="bko-h">${back?'<button class="btn g s" data-act="bkClose">‹ সব বই</button>':''}<span class="bki">${esc(it.ic)}</span><div style="flex:1;min-width:140px"><b>${esc(it.t)}</b><div class="mut sm">${it.done}/${it.n} chapters complete</div></div><span class="chip a">${Math.round(it.pct)}%</span></div>${bar(it.pct,it.c)}<div class="bko-r">${bkRows(it)||'<div class="empty">Nothing found 🔍</div>'}</div></div></div></section>`}
chapterList=function(){const items=bkItems(),filt=!!UI.q||(UI.cseg==='core'&&UI.fp!=='');
 if(filt){const f=items.filter(x=>x.cnt);return f.map(it=>bkOpen(it,0,0)).join('')||'<div class="empty">Nothing found 🔍</div>'}
 const cur=items.find(x=>x.k===UI.book);if(cur){const fr=UI.bkNew;UI.bkNew=0;return bkOpen(cur,fr,1)}
 return`<div class="bks">${items.map(bkCover).join('')}</div>`};
const bkScroll=()=>setTimeout(()=>{const e=$('#bko');e&&e.scrollIntoView({behavior:'smooth',block:'start'})},60);
Object.assign(ACT,{
 bkOpen:el=>{UI.book=el.dataset.k;UI.bkNew=1;vib(10);render(false);bkScroll()},
 bkClose:()=>{const e=$('#bko');if(e)e.classList.add('closing');setTimeout(()=>{UI.book='';UI.bkNew=0;render(false);window.scrollTo({top:0,behavior:'smooth'})},e?280:0)},
 chSub:el=>{UI.cseg='core';UI.q='';UI.fp='';UI.book=UI.book===el.dataset.k?'':el.dataset.k;UI.bkNew=!!UI.book;render(false);if(UI.book)bkScroll()},
 cseg:el=>{UI.cseg=el.dataset.k;UI.book='';render(false)}});
/* fresh start: wipe everything (device + Firebase + files) */
const clrDB=(name,store)=>new Promise(ok=>{try{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{try{r.result.createObjectStore(store)}catch(e){}};r.onerror=()=>ok();r.onblocked=()=>ok();r.onsuccess=()=>{try{const db=r.result;if(!db.objectStoreNames.contains(store)){db.close();return ok()}const tx=db.transaction(store,'readwrite');tx.objectStore(store).clear();tx.oncomplete=()=>{db.close();ok()};tx.onerror=tx.onabort=()=>{db.close();ok()}}catch(e){ok()}}}catch(e){ok()}});
ACT.freshStart=()=>modal(`<h3 style="margin-bottom:10px">🚀 Fresh start (go live)</h3><div class="mut sm" style="margin-bottom:14px;line-height:1.6">This erases <b>everything</b> — progress, tests, tasks, notes, My Why, files, music, YouTube folders, class time and badges — on this device <b>and in Firebase</b>. Only your name and look (theme) stay. It cannot be undone.</div><div class="row wrap"><button class="btn d" id="fsGo" data-act="freshGo">Yes, erase everything</button><button class="btn g" data-act="close">Cancel</button></div>`);
ACT.freshGo=async()=>{const b=$('#fsGo');if(b){b.disabled=true;b.textContent='Erasing…'}
 try{try{AU.pause()}catch(e){}try{ytOff()}catch(e){}
  const N=DEF();N.name=S.name||'';N.set=Object.assign({},S.set,{links:DEF().set.links});N.onb=1;N.start=today();N.u=Date.now();
  await Promise.all([clrDB('mm_vid','v'),clrDB('mm_mus','m')]);
  try{localStorage.removeItem('mm_mus');localStorage.removeItem('mm_mus2');sessionStorage.removeItem('mm_ws')}catch(e){}
  try{MZ.list=[];MZ.idx=-1;AU.removeAttribute('src');AU.load();AQ.length=0}catch(e){}
  Object.keys(S).forEach(k=>delete S[k]);Object.assign(S,N);
  try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}
  if(CL.on&&CL.ref){try{CL.ref.off()}catch(e){}await Promise.race([CL.ref.set({u:S.u,data:JSON.stringify(S)}),new Promise(r=>setTimeout(r,6000))]).catch(()=>{})}
  toast('🚀 Fresh start — everything cleared','ok');
 }catch(e){toast('Something went wrong, reloading…','bad')}
 setTimeout(()=>location.reload(),400)};

