/* ============ v3: chapter link sheet + class links ============ */
const YT_SVG='<svg viewBox="0 0 28 20" aria-hidden="true"><rect width="28" height="20" rx="5.5" fill="#f00"/><path d="M11.2 5.6v8.8L18.8 10z" fill="#fff"/></svg>';
function chName(id){const c=CH[id],has=prOf(id)||CAT[ctOf(id)];return`<span class="chw"><button class="chn" data-act="chOpen" data-k="${id}" title="Open links"><span>${esc(c.n)}</span></button>${has?`<span class="tgs">${tagChips(id)}</span>`:''}</span>`}
const fixUrl=u=>{u=(u||'').trim();return u&&!/^[a-z][a-z0-9+.-]*:/i.test(u)?'https://'+u:u};
const hostOf=u=>{try{return new URL(fixUrl(u).replace(/\{q\}/g,'x')).hostname.replace(/^www\./,'')}catch(e){return u}};
const lkGet=id=>(S.set.links||[]).find(x=>x.id===id);
const lkIni=l=>esc(((l.name||'?').trim().slice(0,3)||'?').toUpperCase());
const ytUrl=id=>'https://www.youtube.com/results?search_query='+encodeURIComponent(CH[id].n+' '+SUBJ[CH[id].s].n);
const lkUrl=(l,id)=>fixUrl(l.url).replace(/\{q\}/g,encodeURIComponent(CH[id].n));
function openExt(u){const a=document.createElement('a');a.href=u;a.target='_blank';a.rel='noopener noreferrer';document.body.appendChild(a);a.click();a.remove()}
function closeSheet(now){const e=$('#lks');if(!e)return;if(now||S.set.calm){e.remove();return}e.classList.add('out');setTimeout(()=>e.remove(),270)}
function chSheet(id,el){closeSheet(true);const c=CH[id];if(!c)return;const sj=SUBJ[c.s],L=S.set.links||[],pr=prOf(id);
  const r=el.getBoundingClientRect(),dx=Math.round(r.left+r.width/2-innerWidth/2),dy=Math.round(r.top+r.height/2-innerHeight/2);
  const T=[{k:'yt',n:'YouTube',s:'Search this chapter',c:'#ff3030',cls:'yt',ic:YT_SVG}];
  L.forEach((l,i)=>T.push({k:'l:'+l.id,n:l.name||'Link',s:l.url?hostOf(l.url):'Tap to set link',c:l.col||TKC[(i+1)%TKC.length],cls:l.url?'':'miss',ic:l.logo?`<img src="${esc(l.logo)}" alt="">`:`<em class="lkt-ini">${lkIni(l)}</em>`}));
  T.push({k:'tag',n:'Tag',s:pr?PRI[pr][2]+' '+PRI[pr][0]:'Priority · type',c:'#a78bfa',cls:'tagt',ic:'<span style="font-size:1.4rem">🏷</span>'});
  const e=document.createElement('div');e.id='lks';e.className='lks';e.setAttribute('role','dialog');e.style.setProperty('--dx',dx+'px');e.style.setProperty('--dy',dy+'px');
  e.innerHTML=`<div class="lks-bd" data-act="lkClose"></div><div class="lks-p"><div class="lks-grab"></div><div class="lks-h"><div class="sub" style="--c:${sj.c}">${esc(sj.n)}</div><h3>${esc(c.n)}</h3><button class="lks-x" data-act="lkClose" aria-label="Close">✕</button></div><div class="lks-g">${T.map((t,i)=>`<button class="lkt ${t.cls}" data-act="lkGo" data-k="${esc(t.k)}" data-ch="${id}" style="--i:${i};${t.c?`--tc:${t.c}`:''}"><span class="lkt-ic"><span class="lkt-in">${t.ic}</span></span><b>${esc(t.n)}</b><small>${esc(t.s)}</small></button>`).join('')}</div>${clBlock(id)}<button class="lks-set" data-act="lkSet">⚙ Manage class links</button></div>`;
  document.body.appendChild(e);vib(8);L.forEach(l=>{if(l.logo&&!l.col)logoCol(l.logo,col=>{l.col=col;save();const t=e.querySelector('.lkt[data-k="l:'+l.id+'"]');if(t)t.style.setProperty('--tc',col)})})}
function lkRow(l){return`<div class="lkr" data-id="${l.id}"><label class="lkr-logo" title="Upload logo" style="--tc:${l.col||'var(--a1)'}">${l.logo?`<img src="${esc(l.logo)}" alt="">`:`<b>${lkIni(l)}</b>`}<input type="file" accept="image/*" data-in="lkLogo" data-k="${l.id}" style="display:none"></label><div class="lkr-f"><input class="field" placeholder="Name (e.g. FRB)" value="${esc(l.name)}" data-in="lkName" data-k="${l.id}" maxlength="20"><input class="field" placeholder="https://…  ({q} = chapter name)" value="${esc(l.url)}" data-in="lkUrl" data-k="${l.id}" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false">${l.logo?`<button class="lkr-rm" data-act="lkRmLogo" data-k="${l.id}">Remove logo</button>`:''}</div><button class="x" data-act="lkDel" data-k="${l.id}" title="Delete">✕</button></div>`}
function linksCard(){const L=S.set.links||[];return`<section class="card rise" style="${ri()}"><div class="row sp"><h3>🔗 Class links</h3><span class="chip a">${L.length+1} options</span></div><div class="mut sm" style="margin:6px 0 14px">Add a link and a logo. They pop up (with YouTube) when you tap any chapter name. Tip: put <b>{q}</b> in a link and it becomes the chapter name, e.g. <b>https://site.com/search?q={q}</b>. Without {q} the link opens as it is.</div><div class="lkl">${L.map(lkRow).join('')||'<div class="empty">No links yet.</div>'}</div><button class="btn g" data-act="lkAdd" style="margin-top:6px">＋ Add link</button></section>`}
Object.assign(ACT,{
  chOpen:(el)=>chSheet(el.dataset.k,el),
  lkClose:()=>closeSheet(),
  lkSet:()=>{closeSheet();setTimeout(()=>go('settings'),160)},
  lkGo:el=>{const k=el.dataset.k,id=el.dataset.ch;
    if(k==='tag'){closeSheet();setTimeout(()=>tagModal(id),200);return}
    let u='';
    if(k==='yt'){el.classList.add('go');vib(14);openYT(id);setTimeout(()=>closeSheet(),420);return}
    else{const l=lkGet(k.slice(2));if(!l)return;if(!fixUrl(l.url)){closeSheet();toast('Add a link for '+(l.name||'this option')+' in Class links','bad');setTimeout(()=>go('settings'),160);return}u=lkUrl(l,id)}
    el.classList.add('go');vib(14);openExt(u);setTimeout(()=>closeSheet(),420)},
  lkAdd:()=>{S.set.links=S.set.links||[];S.set.links.push({id:uid(),name:'',url:'',logo:''});save();render(false);setTimeout(()=>{const i=$$('.lkr input[data-in="lkName"]').pop();if(i){i.scrollIntoView({block:'center',behavior:'smooth'});i.focus()}},60)},
  lkDel:el=>{S.set.links=(S.set.links||[]).filter(x=>x.id!==el.dataset.k);save();render(false)},
  lkRmLogo:el=>{const l=lkGet(el.dataset.k);if(l){l.logo='';save();render(false)}}
});
Object.assign(IN,{
  lkName:e=>{const l=lkGet(e.dataset.k);if(!l)return;l.name=e.value;save();const b=e.closest('.lkr').querySelector('.lkr-logo b');if(b)b.textContent=((e.value.trim().slice(0,3))||'?').toUpperCase()},
  lkUrl:e=>{const l=lkGet(e.dataset.k);if(!l)return;l.url=e.value;save()},
  lkLogo:e=>{const f=e.files[0],l=lkGet(e.dataset.k);if(!f||!l)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const M=128,iw=im.naturalWidth||M,ih=im.naturalHeight||M,ar=iw/ih,c=document.createElement('canvas');c.width=c.height=M;const x=c.getContext('2d'),s=ar>.7&&ar<1.43?Math.max(M/iw,M/ih):Math.min(M/iw,M/ih)*.9,w=iw*s,h=ih*s;x.drawImage(im,(M-w)/2,(M-h)/2,w,h);l.col=domColor(c);l.logo=c.toDataURL('image/png');save();toast('Logo added','ok');render(false)};im.onerror=()=>toast('Could not read that image','bad');im.src=r.result};r.readAsDataURL(f);e.value=''}
});
{const _acc=ACT.acc;ACT.acc=el=>{_acc(el);const w=el.closest('.wk');if(w&&w.classList.contains('open')){w.classList.add('opening');setTimeout(()=>w.classList.remove('opening'),1000)}};
 const _wk=ACT.wk;ACT.wk=el=>{_wk(el);const w=$('.wk.open');if(w){w.classList.add('opening');setTimeout(()=>w.classList.remove('opening'),1000)}}}
addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet()});
{let c='';for(let i=1;i<=14;i++)c+=`.wk.opening .dl>:nth-child(${i}){animation-delay:${i*45}ms}`;const st=document.createElement('style');st.textContent=c;document.head.appendChild(st)}


