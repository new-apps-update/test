/* chapters-tab filter */
{const _o=bkOpen;bkOpen=function(it,f,b){const h=_o(it,f,b);if(!it.core&&!it.bio&&false)return h;const c=UI.cf||'';
 const bar2=`<div class="seg" style="margin:4px 0 10px;flex-wrap:wrap">${[['','সব'],['rem','শুধু বাকি'],['half','আধা শেষ'],['cls','Class বাকি']].map(x=>`<button class="${c===x[0]?'on':''}" data-act="cf" data-k="${x[0]}">${x[1]}</button>`).join('')}</div>`;
 return h.replace('<div class="toc-l">',bar2+'<div class="toc-l">')}}
{const ok=(t)=>{const n=t.filter(Boolean).length,c=UI.cf||'';return c===''||(c==='rem'&&n<4)||(c==='half'&&n>0&&n<4)||(c==='cls'&&n>0&&!t[0])};
 const _tc=tocCore,_te=tocEx;tocCore=(id,n)=>ok(gc(id).t)?_tc(id,n):'';tocEx=(k,i,n)=>ok(S.ex[k+'.'+i]||[0,0,0,0])?_te(k,i,n):''}
