/* ===== v3: reminders · chapter links · My Why timing · roadmap map · analytics viz ===== */
(()=>{const st=document.createElement('style');st.textContent=`
.pnc h3{margin-bottom:2px}.pnb{margin-top:12px;border-radius:12px;border:1px solid var(--line);overflow:hidden}
.pnb summary{padding:11px 14px;cursor:pointer;font-weight:700;list-style:none;display:flex;gap:8px;align-items:center}.pnb summary b{margin-left:auto;background:var(--a1);color:#14100a;border-radius:99px;padding:1px 10px;font-size:.78rem}
.pn{display:flex;align-items:center;gap:10px;width:100%;padding:10px 14px;background:none;border:0;border-top:1px solid var(--line);color:var(--tx);font-family:inherit;text-align:left;cursor:pointer}.pn:hover{background:color-mix(in srgb,var(--tx) 5%,transparent)}
.pn-s{width:4px;align-self:stretch;border-radius:3px;flex:none}.pn-t{flex:1;font-weight:600;line-height:1.4}.pn-m{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}.pn-m u{text-decoration:none;font-size:.68rem;font-weight:700;padding:2px 7px;border-radius:99px;background:color-mix(in srgb,var(--bad) 18%,transparent);color:var(--bad)}
.gm{overflow-x:auto;padding-bottom:6px}.gmi{min-width:640px}.gml{display:flex;justify-content:space-between;font-size:.78rem;font-weight:700;margin:12px 0 4px}
.gr,.gw{display:grid;gap:2px}.gr i{height:14px;border-radius:3px;background:color-mix(in srgb,var(--tx) 8%,transparent)}.gr i.td{outline:2px solid var(--tx);outline-offset:1px;z-index:1}.gw b{font-size:.6rem;opacity:.55;text-align:center;border-left:1px solid var(--line)}
.vz{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:16px}
.hm{display:grid;grid-template-rows:repeat(7,1fr);grid-auto-flow:column;gap:3px}.hm i{aspect-ratio:1;border-radius:3px;background:var(--line)}
.tbr{margin:10px 0}.tbr .row{font-size:.82rem;margin-bottom:4px}`;document.head.appendChild(st)})();
const pend=()=>{const half=[],cls=[];Object.keys(CH).forEach(id=>{const t=gc(id).t,n=t.filter(Boolean).length;if(n>0&&n<4)half.push(id);if(n>0&&!t[0])cls.push(id)});return{half,cls}};
const pnRow=id=>{const t=gc(id).t;return`<button class="pn" data-act="cdOpen" data-t="c" data-k="${id}"><span class="pn-s" style="background:${SUBJ[CH[id].s].c}"></span><span class="pn-t">${esc(CH[id].n)}</span><span class="pn-m">${TL.map((x,i)=>t[i]?'':`<u>${x}</u>`).join('')}</span></button>`};
const pnBlk=(ic,ttl,l)=>l.length?`<details class="pnb" ${l.length<=4?'open':''}><summary>${ic} ${ttl}<b>${bnum(l.length)}</b></summary>${l.map(pnRow).join('')}</details>`:'';
const pendCard=()=>{const p=pend();if(!p.half.length&&!p.cls.length)return'';return`<section class="card pnc"><h3>⏳ বাকি আছে</h3><div class="mut sm">শুরু করেছ কিন্তু শেষ করোনি — আগে এগুলো গুছিয়ে নাও</div>${pnBlk('🟠','আধা পড়া chapter',p.half)}${pnBlk('🎓','Class বাকি (অন্য task হয়েছে)',p.cls)}</section>`};
{const _p=PAGES.today;PAGES.today=function(){return pendCard()+_p()}}
const pendPop=()=>{const p=pend();if(!p.half.length&&!p.cls.length)return;try{if(sessionStorage.getItem('mm_pp'))return;sessionStorage.setItem('mm_pp','1')}catch(e){}
 modal(`<h2>⏳ মনে করিয়ে দিই</h2><div class="cd-g">${p.half.length?`<div class="cd-c"><small>🟠 আধা পড়া chapter</small><b>${bnum(p.half.length)} টা</b></div>`:''}${p.cls.length?`<div class="cd-c"><small>🎓 Class বাকি</small><b>${bnum(p.cls.length)} টা</b></div>`:''}</div><div class="row"><button class="btn p" data-act="pendGo">দেখি কোনগুলো</button><button class="btn g" data-act="close">পরে</button></div>`)};
{let n=0;const iv=setInterval(()=>{if(++n>25){clearInterval(iv);return}if(!S.onb||document.getElementById('ws')||$('#mroot').children.length)return;clearInterval(iv);pendPop()},1000)}
