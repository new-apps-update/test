/* ===== arrow-key music control: ▲▼ volume, ◀▶ prev/next (only while music is playing) ===== */
document.addEventListener('keydown',e=>{
 const k=e.key;if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(k)||e.ctrlKey||e.metaKey||e.altKey)return;
 const t=e.target,tg=(t&&t.tagName)||'';if(tg==='TEXTAREA'||tg==='SELECT'||t&&t.isContentEditable||tg==='INPUT'&&t.type!=='range'&&t.type!=='checkbox')return;
 if(typeof FV!=='undefined'&&FV)return;
 if(AU.paused)return;
 e.preventDefault();
 if(k==='ArrowUp'||k==='ArrowDown'){
  MZ.vol=Math.max(0,Math.min(1,Math.round((MZ.vol+(k==='ArrowUp'?.05:-.05))*100)/100));
  mzApplyVol();mzSave();
  document.querySelectorAll('[data-in="mzVol"]').forEach(x=>x.value=Math.round(MZ.vol*100));
  toast('🔊 Volume '+Math.round(MZ.vol*100)+'%','ok');
 }else if(!e.repeat){
  k==='ArrowRight'?ACT.mzNext():ACT.mzPrev();
 }
},true);
