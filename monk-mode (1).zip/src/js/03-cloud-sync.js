/* ============ cloud sync (Firebase Realtime Database) ============ */
/* >>> Paste your Firebase web-app config here (Project settings > Your apps). databaseURL is required. <<< */
const FB_CONFIG={apiKey:"AIzaSyC_1y7gQn-8Uyik6o9PdG8M7fu54RgbUq0",authDomain:"monk-mode-39243.firebaseapp.com",databaseURL:"https://monk-mode-39243-default-rtdb.asia-southeast1.firebasedatabase.app",projectId:"monk-mode-39243",storageBucket:"monk-mode-39243.firebasestorage.app",messagingSenderId:"943166682895",appId:"1:943166682895:web:9dd6498ee3d67b39cdb07a"};
const CL={on:false,ref:null,t:0,st:'off'};
const ldScript=u=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=u;s.onload=ok;s.onerror=no;document.head.appendChild(s)});
const syncCode=()=>'main';
function cloudState(s){CL.st=s;const e=$('#cl');if(e){e.className='cld '+s;e.title=s==='ok'?'Synced':s==='err'?'Offline':s==='sync'?'Syncing…':'Local'}}
async function cloudInit(){if(!FB_CONFIG.databaseURL){cloudState('off');return false}
 try{const v='10.12.2';if(!window.firebase){await ldScript(`https://www.gstatic.com/firebasejs/${v}/firebase-app-compat.js`);await ldScript(`https://www.gstatic.com/firebasejs/${v}/firebase-database-compat.js`)}
 if(!firebase.apps.length)firebase.initializeApp(FB_CONFIG);CL.ref=firebase.database().ref('monkmode/'+syncCode());CL.on=true;cloudState('sync');
 return await new Promise(res=>{let first=true;CL.ref.on('value',snap=>{const v=snap.val();cloudState('ok');
  if(v&&v.data&&(v.u||0)>(S.u||0)){try{const d=JSON.parse(v.data);S=Object.assign(DEF(),d,{set:Object.assign(DEF().set,d.set||{})});localStorage.setItem(KEY,JSON.stringify(S));applyTheme();applyIcon();document.documentElement.style.setProperty('--fs',S.set.fs+'px');if(S.onb)closeModal();render(false)}catch(e){}}
  else if(first&&(!v||(v.u||0)<(S.u||0)))cloudPush(true);
  if(first){first=false;res(true)}},()=>{cloudState('err');if(first){first=false;res(false)}})})}catch(e){cloudState('err');return false}}
function cloudPush(now){if(!CL.on)return;clearTimeout(CL.t);CL.t=setTimeout(()=>{try{if(!S.u)S.u=Date.now();cloudState('sync');CL.ref.set({u:S.u,data:JSON.stringify(S)}).then(()=>cloudState('ok')).catch(()=>cloudState('err'))}catch(e){cloudState('err')}},now?0:600)}

