// src/ -> index.html. Run: node build.js
const fs=require('fs'),path=require('path'),S=path.join(__dirname,'src');
const rd=p=>fs.readFileSync(p,'utf8'),ls=d=>fs.readdirSync(path.join(S,d)).sort().map(f=>path.join(S,d,f));
const W=JSON.parse(rd(S+'/_wrap.json'));
const css=ls('css').map(rd).join('\n');
const mods=ls('js').filter(f=>!f.endsWith('zz-after-app-keys.js'));
const js=W.js_head+'\n'+mods.map(rd).join('')+W.js_mid+'\n'+rd(S+'/js/zz-after-app-keys.js');
let out=rd(S+'/_tpl.html').replace('\n@@CSS@@\n',()=>css).replace('\n@@JS@@\n',()=>js);
out=out.replace(/@@ASSET:(\w+)@@/g,(m,n)=>rd(S+'/assets/'+n+'.txt'));

fs.writeFileSync(__dirname+'/index.html',out);fs.copyFileSync(S+'/static/sw.js',__dirname+'/sw.js');
console.log('built index.html',Math.round(out.length/1024),'KB');
