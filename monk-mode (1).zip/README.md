# Monk Mode — প্রজেক্ট গাইড

## কীভাবে চালাবে
- `index.html` ডাবল-ক্লিক করলেই app খোলে (একটাই ফাইল, সব ভেতরে)।
- **GitHub Pages:** zip খুলে ভেতরের সব ফাইল/ফোল্ডার একসাথে repo-তে upload করো → Settings → Pages → Branch: main, folder: / (root)। `index.html` আর `sw.js` root-এই আছে, তাই সরাসরি চলবে।
- **ঠিকানা বদলালে data দেখা যাবে না** (browser আলাদা ঠিকানার data আলাদা রাখে)। তাই আগে Settings → Export backup, নতুন জায়গায় Import backup।

## সম্পাদনার নিয়ম
`src/` এ কাজ হয়, root-এর `index.html` হলো তৈরি-করা ফল। কিছু বদলালে `python build.py` (বা `node build.js`) চালালে `index.html` নতুন হয়।
Claude-কে zip দিয়ে শুধু বলবে কী চাও; সে `src/` এর সঠিক ফাইল বদলে rebuild করে দেবে।

## কোন কাজ কোন ফাইলে (`src/js/`)
| ফাইল | কী আছে |
|---|---|
| 00-helpers | তারিখ, ছোট helper ফাংশন |
| 01-data-routine | বিষয়, chapter তালিকা, ৮৪ দিনের routine (Q), **EXTRA (বাংলা/ইংরেজি/ICT/Bio chapter নাম)** |
| 02-state | save/load, ডিফল্ট সেটিং |
| 03-cloud-sync | Firebase sync |
| 04-ui-atoms | bar, ring, task বাটন ইত্যাদি ছোট UI |
| 05-pages-today-roadmap-settings | Today, Roadmap, Settings পাতার মূল কোড |
| 06-analytics | Stats পাতার মূল হিসাব |
| 07-render / 08-actions | পাতা আঁকা, সব বাটনের action (ACT) |
| 09-theme-background-confetti | theme, background animation |
| 10-tags-fx-themes | chapter tag (priority/category), effect |
| 11-class-links-sheet | chapter নামে চাপলে link sheet, Class links |
| 12 / 13 / 14 | পরের দিকের ফিচার (v4–v6): hero, wrap-up, badges ইত্যাদি |
| 15-mock-tests-music | mock test, music player |
| 16-workspace-music-visuals | Files, Music, Tasks, Notes |
| 17-stats-badges-settings | badge, performance, settings |
| 18-about-music-chapters-analytics | About, music animation, extra analytics |
| 19-youtube-folders | YouTube folder |
| 20-floating-music | ভাসমান music বাটন |
| 21-chapters-book-covers-fresh-start | বইয়ের cover, Fresh start |
| **22-extra-quest-bio-blocks** | **Extra Quest (৪ block), Bio 5★/3★/2★ block ক্রম (BIOB)** |
| **23-toc-chapter-detail** | **সূচিপত্র-style বই, chapter detail sheet** |
| **24-reminders-today** | **Today-র "বাকি আছে" card + খোলার popup** |
| 25-chapter-filter | সূচিপত্রের filter (বাকি / আধা / Class বাকি) |
| 26-chapter-links | শুধু ওই chapter-এর আলাদা link |
| 27-my-why-timing | My Why কখন দেখাবে |
| 28-roadmap-journey-map | Roadmap-এর Journey map |
| 29-analytics-visuals | Radar, heatmap, task bar |
| 30-actions-reminders-links-why | ওপরের ফিচারের বাটন action |
| 99-boot | app চালু করার কোড (সবার শেষে) |
| zz-after-app-keys | তীর-চাবি দিয়ে music control |

ফাইলগুলো নামের ক্রমে জোড়া লাগে — ক্রম বদলাবে না। CSS আছে `src/css/`, ছবির data (icon) `src/assets/`, মূল HTML কাঠামো `src/_tpl.html`।

## দ্রুত খোঁজা
- Bio ক্রম বদলাতে: `22-…` এর `BIOB`
- Chapter নামের বানান: `01-data-routine` (`EXTRA`, `PRIME`)
- Extra Quest-এর চেহারা: `22-…` (`xqBody`)
- সূচিপত্র / chapter detail: `23-…`
- Reminder লেখা: `24-…`
