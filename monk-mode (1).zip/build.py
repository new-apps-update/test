#!/usr/bin/env python3
"""src/ -> index.html (project root) (single file, works by double-click). Run: python build.py"""
import os,re,json,glob
R=os.path.dirname(os.path.abspath(__file__));S=os.path.join(R,'src')
rd=lambda p:open(p,encoding='utf8').read()
W=json.loads(rd(S+'/_wrap.json'))
css='\n'.join(rd(f) for f in sorted(glob.glob(S+'/css/*.css')))
mods=[f for f in sorted(glob.glob(S+'/js/*.js')) if not f.endswith('zz-after-app-keys.js')]
js=W['js_head']+'\n'+''.join(rd(f) for f in mods)+W['js_mid']+'\n'+rd(S+'/js/zz-after-app-keys.js')
out=rd(S+'/_tpl.html').replace('\n@@CSS@@\n',css,1).replace('\n@@JS@@\n',js,1)
out=re.sub(r'@@ASSET:(\w+)@@',lambda m:rd(S+'/assets/'+m.group(1)+'.txt'),out)
os.makedirs(R,exist_ok=True)
open(R+'/index.html','w',encoding='utf8',newline='').write(out)
open(R+'/sw.js','w',encoding='utf8').write(rd(S+'/static/sw.js'))
print('built index.html',len(out)//1024,'KB')
